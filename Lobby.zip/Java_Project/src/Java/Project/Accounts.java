package Java.Project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class Accounts implements ActionListener {
    JFrame jFrame;
    JLabel jLabel,jLabel2;
    JButton jButton, jButton1, jButton2,jButton3;
    JPanel jPanel;

    Accounts() {
        // Initialize the frame
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        // Initialize and set up the panel
        jPanel = new JPanel();
        jPanel.setBounds(0, 0, 1400, 760);
        jPanel.setBackground(Color.black);
        jPanel.setLayout(null);

        // Initialize and set up the label
        jLabel = new JLabel("Yousaf Safeer");
        jLabel.setForeground(Color.WHITE);
        jLabel.setBackground(Color.black);
        jLabel.setFont(new Font("INHERIT", Font.BOLD, 50));
        jLabel.setBounds(520, 100, 600, 50); // Adjusted bounds to fit within the jPanel
        jLabel.setOpaque(true);
        jPanel.add(jLabel);

        jLabel2 = new JLabel("Email: yousafsafeer0@gmail.com");
        jLabel2.setForeground(Color.WHITE);
        jLabel2.setBackground(Color.black);
        jLabel2.setFont(new Font("INHERIT", Font.BOLD, 16));
        jLabel2.setBounds(520, 150, 300, 50); // Adjusted bounds to fit within the jPanel
        jLabel2.setOpaque(true);
        jPanel.add(jLabel2);

        // Initialize the button before using it
        jButton = new JButton("Test1");
        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\IdeaProjects\\Java_Project\\src\\Java\\Project\\Design For Project JAVA (3).png");
        jButton.setIcon(i);
        jButton.setBounds(100, 100, 400, 300);
        jButton.addActionListener(this);
        jPanel.add(jButton);

        // Initialize and set up the switch button
        jButton1 = new JButton("Switch");
        jButton1.setBackground(Color.DARK_GRAY);
        jButton1.setForeground(Color.WHITE);
        jButton1.setFocusable(false);
        jButton1.setFont(new Font("Serif", Font.PLAIN, 12));
        jButton1.setBounds(1250, 650, 100, 30);
        jButton1.addActionListener(this);
        jPanel.add(jButton1);

        // Initialize and set up the logout button
        jButton2 = new JButton("Logout");
        jButton2.setBackground(Color.DARK_GRAY);
        jButton2.setFocusable(false);
        jButton2.setForeground(Color.WHITE);
        jButton2.setFont(new Font("Serif", Font.PLAIN, 12));
        jButton2.setBounds(1250, 5, 100, 50);
        jButton2.addActionListener(this);
        jPanel.add(jButton2);

        jButton3 = new JButton("Back");
        jButton3.setBackground(Color.DARK_GRAY);
        jButton3.setFocusable(false);
        jButton3.setForeground(Color.WHITE);
        jButton3.setFont(new Font("Serif", Font.PLAIN, 12));
        jButton3.setBounds(5, 5, 70, 30);
        jButton3.addActionListener(this);
        jPanel.add(jButton3);

        // Add the panel to the frame and set the frame visible
        jFrame.add(jPanel);
        jFrame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == jButton) {
            new Pic();
        } else if (e.getSource() == jButton1) {
            jFrame.dispose();
            new Select();
        } else if (e.getSource() == jButton2) {
            new Login();
            jFrame.dispose();
        } else if (e.getSource()==jButton3) {
            new UI();
            jFrame.dispose();

        }
    }

    public static void main(String[] args) {
        new Accounts();
    }
}

// Same Account Section to Divide Kids and Adult Sections.

class Accounts_KSection implements ActionListener {
    JFrame jFrame;
    JLabel jLabel,jLabel2;
    JButton jButton, jButton1, jButton2,jButton3;
    JPanel jPanel;

    Accounts_KSection() {
        // Initialize the frame
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        // Initialize and set up the panel
        jPanel = new JPanel();
        jPanel.setBounds(0, 0, 1400, 760);
        jPanel.setBackground(Color.black);
        jPanel.setLayout(null);

        // Initialize and set up the label
        jLabel = new JLabel("Yousaf Safeer");
        jLabel.setForeground(Color.WHITE);
        jLabel.setBackground(Color.black);
        jLabel.setFont(new Font("INHERIT", Font.BOLD, 50));
        jLabel.setBounds(520, 100, 600, 50); // Adjusted bounds to fit within the jPanel
        jLabel.setOpaque(true);
        jPanel.add(jLabel);

        jLabel2 = new JLabel("Email: yousafsafeer0@gmail.com");
        jLabel2.setForeground(Color.WHITE);
        jLabel2.setBackground(Color.black);
        jLabel2.setFont(new Font("INHERIT", Font.BOLD, 16));
        jLabel2.setBounds(520, 150, 300, 50);; // Adjusted bounds to fit within the jPanel
        jLabel2.setOpaque(true);
        jPanel.add(jLabel2);

        // Initialize the button before using it
        jButton = new JButton("Test1");
        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\IdeaProjects\\Java_Project\\src\\Java\\Project\\Design For Project JAVA (3).png");
        jButton.setIcon(i);
        jButton.setBounds(100, 100, 400, 300);
        jButton.addActionListener(this);
        jPanel.add(jButton);

        // Initialize and set up the switch button
        jButton1 = new JButton("Switch");
        jButton1.setBackground(Color.DARK_GRAY);
        jButton1.setForeground(Color.WHITE);
        jButton1.setFocusable(false);
        jButton1.setFont(new Font("Serif", Font.PLAIN, 12));
        jButton1.setBounds(1250, 650, 100, 30);
        jButton1.addActionListener(this);
        jPanel.add(jButton1);

        // Initialize and set up the logout button
        jButton2 = new JButton("Logout");
        jButton2.setBackground(Color.DARK_GRAY);
        jButton2.setFocusable(false);
        jButton2.setForeground(Color.WHITE);
        jButton2.setFont(new Font("Serif", Font.PLAIN, 12));
        jButton2.setBounds(1250, 5, 100, 50);
        jButton2.addActionListener(this);
        jPanel.add(jButton2);

        jButton3 = new JButton("Back");
        jButton3.setBackground(Color.DARK_GRAY);
        jButton3.setFocusable(false);
        jButton3.setForeground(Color.WHITE);
        jButton3.setFont(new Font("Serif", Font.PLAIN, 12));
        jButton3.setBounds(5, 5, 70, 30);
        jButton3.addActionListener(this);
        jPanel.add(jButton3);

        // Add the panel to the frame and set the frame visible
        jFrame.add(jPanel);
        jFrame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == jButton) {
            new Pic();
        } else if (e.getSource() == jButton1) {
            new Select();
            jFrame.dispose();

        } else if (e.getSource() == jButton2) {
            jFrame.dispose();
            new Login();
        } else if (e.getSource()==jButton3) {
            jFrame.dispose();
            new Kids_UI();

        }
    }

    public static void main(String[] args) {
        new Accounts();
    }
}

