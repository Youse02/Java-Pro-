package Java.Project;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.plaf.ColorUIResource;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class Show1 implements ActionListener {

        JFrame jFrame;
        JLabel jLabel;
        JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
        JButton jButton10,jButton11,jButton12;
        JPanel  jPanel1, jPanel2;
        JButton backButton;

        Show1(){
            jFrame = new JFrame();
            jFrame.setSize(1400, 760);
            jFrame.setResizable(false);
            jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            jFrame.setLayout(null);

            jPanel1 = new JPanel();
            jPanel1.setBounds(0, 0, 40, 760);
            jPanel1.setBackground(Color.BLACK);
            jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
            jPanel1.setLayout(null);

            ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
            Home = new JButton();
            Home.setBounds(0,1,40,40);
            Home.addActionListener(this);
            Home.setIcon(ih);


            jPanel1. add(Home);


            jPanel2 = new JPanel();
            jPanel2.setBounds(30, 0, 1360, 760);
            jPanel2.setBackground(Color.BLACK);
            jPanel2.setLayout(null);

            ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
            jButton = new JButton();
            jButton.setBounds(20, 20, 110, 150);
            jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton.addActionListener(this);
            jButton.setIcon(i);
            jPanel2.add(jButton);

            ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
            jButton1 = new JButton();
            jButton1.setBounds(150, 20, 110, 150);
            jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton1.addActionListener(this);
            jButton1.setIcon(i1);
            jPanel2.add(jButton1);

            ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
            jButton2 = new JButton();
            jButton2.setBounds(280, 20, 110, 150);
            jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton2.addActionListener(this);
            jButton2.setIcon(i2);
            jPanel2.add(jButton2);

            ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
            jButton3 = new JButton();
            jButton3.setBounds(410, 20, 110, 150);
            jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton3.addActionListener(this);
            jButton3.setIcon(i3);
            jPanel2.add(jButton3);

            ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
            jButton4 = new JButton();
            jButton4.setBounds(540, 20, 110, 150);
            jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton4.addActionListener(this);
            jButton4.setIcon(i4);
            jPanel2.add(jButton4);

            ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
            jButton5 = new JButton();
            jButton5.setBounds(670, 20, 110, 150);
            jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton5.addActionListener(this);
            jButton5.setIcon(i5);
            jPanel2.add(jButton5);

            ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
            jButton6 = new JButton();
            jButton6.setBounds(800,20,110, 150);
            jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton6.addActionListener(this);
            jButton6.setIcon(i6);
            jPanel2.add(jButton6);

            ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
            jButton7 = new JButton();
            jButton7.setBounds(930, 20, 110, 150);
            jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton7.addActionListener(this);
            jButton7.setIcon(i7);
            jPanel2.add(jButton7);

            ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
            jButton8 = new JButton();
            jButton8.setBounds(1060, 20, 110, 150);
            jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton8.addActionListener(this);
            jButton8.setIcon(i8);
            jPanel2.add(jButton8);

            ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
            jButton9 = new JButton();
            jButton9.setBounds(1190, 20, 110, 150);
            jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton9.addActionListener(this);
            jButton9.setIcon(i9);
            jPanel2.add(jButton9);

            ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
            jButton10 = new JButton();
            jButton10.setBounds(20, 190, 110, 150);
            jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton10.addActionListener(this);
            jButton10.setIcon(i10);
            jPanel2.add(jButton10);

            ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
            jButton11 = new JButton();
            jButton11.setBounds(150, 190, 110, 150);
            jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton11.addActionListener(this);
            jButton11.setIcon(i11);
            jPanel2.add(jButton11);

            ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
            jButton12 = new JButton();
            jButton12.setBounds(280, 190, 110, 150);
            jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton12.addActionListener(this);
            jButton12.setIcon(i12);
            jPanel2.add(jButton12);

            backButton = new JButton();
            backButton.setBounds(1200,650,100,50);
            backButton.addActionListener(this);
            jPanel2.add(backButton);

        }


        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource()==Home){
                jFrame .dispose();
                new UI();
            }
            else if (e.getSource()==backButton) {
                jFrame. dispose();
                new Shows();

            }
        }
    }



class Show2 implements ActionListener {


    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show2(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);


        jPanel1. add(Home);


        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show3 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show3(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);


        jPanel1. add(Home);
        jPanel1.add(Account);


        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show4 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show4(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show5 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show5(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);


        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show6 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show6(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);
        jPanel1.add(Account);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show7 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show7(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show8 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show8(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show9 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;
    Show9(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show10 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show10(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show11 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show11(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show12 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show12(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show13 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show13(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }

}

class Show14 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show14(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show15 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show15(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show16 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show16(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show17 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButto7n16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show17(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show18 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show18(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);


        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }
}

class Show19 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Show19(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Shows();

        }
    }

}

    class Show20 implements ActionListener {

        JFrame jFrame;
        JLabel jLabel;
        JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
        JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
        JPanel jPanel,jPanel1, jPanel2;
        JButton backButton;

        Show20(){
            jFrame = new JFrame();
            jFrame.setSize(1400, 760);
            jFrame.setResizable(false);
            jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            jFrame.setLayout(null);

            jPanel1 = new JPanel();
            jPanel1.setBounds(0, 0, 40, 760);
            jPanel1.setBackground(Color.BLACK);
            jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
            jPanel1.setLayout(null);

            ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
            Home = new JButton();
            Home.setBounds(0,1,40,40);
            Home.addActionListener(this);
            Home.setIcon(ih);


            jPanel1. add(Home);

            jPanel2 = new JPanel();
            jPanel2.setBounds(30, 0, 1360, 760);
            jPanel2.setBackground(Color.BLACK);
            jPanel2.setLayout(null);

            ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
            jButton = new JButton();
            jButton.setBounds(20, 20, 110, 150);
            jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton.addActionListener(this);
            jButton.setIcon(i);
            jPanel2.add(jButton);

            ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
            jButton1 = new JButton();
            jButton1.setBounds(150, 20, 110, 150);
            jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton1.addActionListener(this);
            jButton1.setIcon(i1);
            jPanel2.add(jButton1);

            ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
            jButton2 = new JButton();
            jButton2.setBounds(280, 20, 110, 150);
            jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton2.addActionListener(this);
            jButton2.setIcon(i2);
            jPanel2.add(jButton2);

            ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
            jButton3 = new JButton();
            jButton3.setBounds(410, 20, 110, 150);
            jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton3.addActionListener(this);
            jButton3.setIcon(i3);
            jPanel2.add(jButton3);

            ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
            jButton4 = new JButton();
            jButton4.setBounds(540, 20, 110, 150);
            jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton4.addActionListener(this);
            jButton4.setIcon(i4);
            jPanel2.add(jButton4);

            ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
            jButton5 = new JButton();
            jButton5.setBounds(670, 20, 110, 150);
            jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton5.addActionListener(this);
            jButton5.setIcon(i5);
            jPanel2.add(jButton5);

            ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
            jButton6 = new JButton();
            jButton6.setBounds(800,20,110, 150);
            jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton6.addActionListener(this);
            jButton6.setIcon(i6);
            jPanel2.add(jButton6);

            ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
            jButton7 = new JButton();
            jButton7.setBounds(930, 20, 110, 150);
            jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton7.addActionListener(this);
            jButton7.setIcon(i7);
            jPanel2.add(jButton7);

            ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
            jButton8 = new JButton();
            jButton8.setBounds(1060, 20, 110, 150);
            jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton8.addActionListener(this);
            jButton8.setIcon(i8);
            jPanel2.add(jButton8);

            ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
            jButton9 = new JButton();
            jButton9.setBounds(1190, 20, 110, 150);
            jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton9.addActionListener(this);
            jButton9.setIcon(i9);
            jPanel2.add(jButton9);

            ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
            jButton10 = new JButton();
            jButton10.setBounds(20, 190, 110, 150);
            jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton10.addActionListener(this);
            jButton10.setIcon(i10);
            jPanel2.add(jButton10);

            ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
            jButton11 = new JButton();
            jButton11.setBounds(150, 190, 110, 150);
            jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton11.addActionListener(this);
            jButton11.setIcon(i11);
            jPanel2.add(jButton11);

            ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
            jButton12 = new JButton();
            jButton12.setBounds(280, 190, 110, 150);
            jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
            jButton12.addActionListener(this);
            jButton12.setIcon(i12);
            jPanel2.add(jButton12);

            backButton = new JButton();
            backButton.setBounds(1200,650,100,50);
            backButton.addActionListener(this);
            jPanel2.add(backButton);


            jFrame.add(jPanel1);
            jFrame.add(jPanel2);
            jFrame.setVisible(true);

        }


        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource()==Home){
                jFrame .dispose();
                new UI();
            }
            else if (e.getSource()==backButton) {
                jFrame. dispose();
                new Shows();

            }
        }
    }
