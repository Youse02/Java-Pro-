package Java.Project;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.plaf.ColorUIResource;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class UI implements ActionListener {
    JFrame jFrame;
    JLabel jLabel;
    JButton jButton, jButton1, jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JButton Home,Account,Watch;
    JButton MOVIES, ANIME, SHOWS,CARTOONS;
    JPanel jPanel, jPanel1, jPanel2, mainPanel;
    JScrollPane jScrollPane;

    public UI() {
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel = new JPanel();
        jPanel.setBounds(0, 0, 1400, 760);
        jPanel.setBorder(new LineBorder(Color.BLACK));
        jPanel.setBackground(Color.BLACK);
        jPanel.setLayout(null);

        ImageIcon imageIcon= new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Interface.png");
        jLabel = new JLabel();
        jLabel.setBounds(-50, -50, 1400, 500);
        jLabel.setIcon(imageIcon);
        jLabel.setOpaque(true);

        Watch = new JButton("Watch MHA");
        Watch.setFont(new Font("Serif", Font.BOLD, 20));
        Watch.setBackground(Color.BLACK);
        Watch.setForeground(Color.LIGHT_GRAY);
        Watch.setFocusable(false);
        Watch.addActionListener(this);
        Watch.setBounds(70,400,200,50);
        jLabel.add(Watch);

        jPanel.add(jLabel);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBorder(new LineBorder(Color.BLACK));
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        ImageIcon iA = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Profile.png");
        Account = new JButton();
        Account.setBounds(0,650,40,40);
        Account.addActionListener(this);
        Account.setIcon(iA);

        ImageIcon im = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\movie prooo.png");
        MOVIES = new JButton();
        MOVIES.setBounds(0,100,40,40);
        MOVIES.addActionListener(this);
        MOVIES.setIcon(im);

        ImageIcon ia = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\animeeeeeee pro.png");
        ANIME = new JButton();
        ANIME.setBounds(0,170,40,40);
        ANIME.addActionListener(this);
        ANIME.setIcon(ia);

        ImageIcon is = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\shows pro.png ");
        SHOWS = new JButton();
        SHOWS.setBounds(0,240,40,40);
        SHOWS.addActionListener(this);
        SHOWS.setIcon(is);

        ImageIcon ic = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\cartoon iconnnnn pro.png");
        CARTOONS = new JButton();
        CARTOONS.setBounds(0,310,40,40);
        CARTOONS.addActionListener(this);
        CARTOONS.setIcon(ic);

        jPanel1. add(Home);
        jPanel1.add(Account);
        jPanel1.add(MOVIES);
        jPanel1.add(ANIME);
        jPanel1.add(SHOWS);
        jPanel1.add(CARTOONS);

        jPanel2 = new JPanel();
        jPanel2.setBackground(Color.black);
        jPanel2.setBorder(new LineBorder(Color.BLACK));
        jPanel2.setLayout(null);

        // Set a preferred size for jPanel2 to enable scrolling
        jPanel2.setPreferredSize(new Dimension(1360, 600));

        // Add buttons to jPanel2 (unchanged)

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\BossBaby.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Bahubali 2.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\BatmanBegins.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Brothers.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\BlueLock.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Boruto.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\ChainSawMan.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\ClassRoomOfThe Elite.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\CyberPunk.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Man VS Bee.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Money Heist.png");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        ImageIcon i13 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png");
        jButton13 = new JButton();
        jButton13.setBounds(410, 190, 110, 150);
        jButton13.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton13.addActionListener(this);
        jButton13.setIcon(i13);
        jPanel2.add(jButton13);

        ImageIcon i14 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\PeakyBlinder.png ");
        jButton14 = new JButton();
        jButton14.setBounds(540, 190, 110, 150);
        jButton14.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton14.addActionListener(this);
        jButton14.setIcon(i14);
        jPanel2.add(jButton14);

        ImageIcon i15 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png ");
        jButton15 = new JButton();
        jButton15.setBounds(670, 190, 110, 150);
        jButton15.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton15.addActionListener(this);
        jButton15.setIcon(i15);
        jPanel2.add(jButton15);

        ImageIcon i16 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png ");
        jButton16 = new JButton();
        jButton16.setBounds(800, 190, 110, 150);
        jButton16.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton16.addActionListener(this);
        jButton16.setIcon(i16);
        jPanel2.add(jButton16);

        ImageIcon i17 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png ");
        jButton17 = new JButton();
        jButton17.setBounds(930, 190, 110, 150);
        jButton17.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton17.addActionListener(this);
        jButton17.setIcon(i17);
        jPanel2.add(jButton17);

        ImageIcon i18 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png");
        jButton18 = new JButton();
        jButton18.setBounds(1060, 190, 110, 150);
        jButton18.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton18.addActionListener(this);
        jButton18.setIcon(i18);
        jPanel2.add(jButton18);

        ImageIcon i19 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png ");
        jButton19 = new JButton();
        jButton19.setBounds(1190, 190, 110, 150);
        jButton19.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton19.addActionListener(this);
        jButton19.setIcon(i19);
        jPanel2.add(jButton19);

        // Create a main panel to hold both jPanel and jPanel2
        mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setPreferredSize(new Dimension(1400, 900)); // Adjust size as needed

        // Add jPanel and jPanel2 to mainPanel
        jPanel.setBounds(0, 0, 1360, 430); // Adjust size and position as needed
        mainPanel.add(jPanel);

        jPanel2.setBounds(0, 430, 1360, 600); // Adjust size and position as needed
        mainPanel.add(jPanel2);

        // Add mainPanel to JScrollPane
        jScrollPane = new JScrollPane(mainPanel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane.setBounds(40, 0, 1360, 760);

        jFrame.add(jPanel1);
        jFrame.add(jScrollPane);
        jFrame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Home) {
            jFrame.dispose();
            new UI();
        } else if (e.getSource() == Account) {
            jFrame.dispose();
            new Accounts();
        } else if (e.getSource() == MOVIES) {
            jFrame.dispose();
            new Movies();
        } else if (e.getSource() == ANIME) {
            jFrame.dispose();
            new Animes();
        } else if (e.getSource() == SHOWS) {
            jFrame.dispose();
            new Shows();
        } else if (e.getSource() == CARTOONS) {
            jFrame.dispose();
            new Cartoons();
        } else if (e.getSource()==Watch) {
            jFrame.dispose();
            new Anime19();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource()==jButton5) {
            jFrame.dispose();
            new Anime6();

        }else if (e.getSource()==jButton6) {
            jFrame.dispose();
            new Anime7();

        }else if (e.getSource()==jButton7) {
            jFrame.dispose();
            new Anime8();

        }else if (e.getSource()==jButton8) {
            jFrame.dispose();
            new Anime9();

        }else if (e.getSource()==jButton9) {
            jFrame.dispose();
            new Show10();

        }else if (e.getSource()==jButton10) {
            jFrame.dispose();
            new Show11();

        }else if (e.getSource()==jButton11) {
            jFrame.dispose();
            new Show12();

        }else if (e.getSource()==jButton12) {
            jFrame.dispose();
            new Show13();

        }
        else if (e.getSource()==jButton13) {
            jFrame.dispose();
            new Show14();
        }
             else if (e.getSource() == jButton15) {
                jFrame.dispose();
                new Cartoon16();

            }
            else if (e.getSource() == jButton16) {
                jFrame.dispose();
                new Cartoon17();

            }
            else if (e.getSource() == jButton17) {
                jFrame.dispose();
                new Cartoon18();

            }
            else if (e.getSource() == jButton18) {
                jFrame.dispose();
                new Cartoon19();

            }
            else if (e.getSource() == jButton19) {
                jFrame.dispose();
                new Cartoon20();

            }


    }
}



 class Kids_UI implements ActionListener {
    JFrame jFrame;
    JLabel jLabel;
    JButton jButton, jButton1, jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JButton Home,Account;
    JButton SHOWS,CARTOONS,Watch;
    JPanel jPanel, jPanel1, jPanel2, mainPanel;
    JScrollPane jScrollPane;

    public Kids_UI() {
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel = new JPanel();
        jPanel.setBounds(0, 0, 1400, 760);
        jPanel.setBackground(Color.black);
        jPanel.setLayout(null);

        ImageIcon imageIcon =new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Interface Kids.png");

        jLabel = new JLabel();
        jLabel.setBounds(-50, -50, 1400, 500);
        jLabel.setIcon(imageIcon);
        jLabel.setOpaque(true);

        Watch = new JButton("Watch Tom&Jerry");
        Watch.setFont(new Font("Serif", Font.BOLD, 20));
        Watch.setBackground(Color.BLACK);
        Watch.setForeground(Color.LIGHT_GRAY);
        Watch.setFocusable(false);
        Watch.addActionListener(this);
        Watch.setBounds(70,400,200,50);
        jLabel.add(Watch);

        jPanel.add(jLabel);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.gray);
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.setIcon(ih);
        Home.addActionListener(this);

        ImageIcon iA = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Profile.png");
        Account = new JButton();
        Account.setBounds(0,650,40,40);
        Account.setIcon(iA);
        Account.addActionListener(this);

        ImageIcon is = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\shows pro.png");
        SHOWS = new JButton();
        SHOWS.setBounds(0,100,40,40);
        SHOWS.setIcon(is);
        SHOWS.addActionListener(this);

        ImageIcon ic = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\cartoon iconnnnn pro.png");
        CARTOONS = new JButton();
        CARTOONS.setBounds(0,170,40,40);
        CARTOONS.setIcon(ic);
        CARTOONS.addActionListener(this);

        jPanel1.add(Home);
        jPanel1.add(Account);
        jPanel1.add(SHOWS);
        jPanel1.add(CARTOONS);

        jPanel2 = new JPanel();
        jPanel2.setBackground(Color.lightGray);
        jPanel2.setLayout(null);

        // Set a preferred size for jPanel2 to enable scrolling
        jPanel2.setPreferredSize(new Dimension(1360, 600));

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        // Add buttons to jPanel2 (unchanged)
        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Man VS Bee.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Money Heist.png");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        ImageIcon i13 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png");
        jButton13 = new JButton();
        jButton13.setBounds(410, 190, 110, 150);
        jButton13.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton13.addActionListener(this);
        jButton13.setIcon(i13);
        jPanel2.add(jButton13);

        ImageIcon i14 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\PeakyBlinder.png ");
        jButton14 = new JButton();
        jButton14.setBounds(540, 190, 110, 150);
        jButton14.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton14.addActionListener(this);
        jButton14.setIcon(i14);
        jPanel2.add(jButton14);

        ImageIcon i15 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\School 2017.png");
        jButton15 = new JButton();
        jButton15.setBounds(670, 190, 110, 150);
        jButton15.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton15.addActionListener(this);
        jButton15.setIcon(i15);
        jPanel2.add(jButton15);

        ImageIcon i16 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Squid Game.png");
        jButton16 = new JButton();
        jButton16.setBounds(800, 190, 110, 150);
        jButton16.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton16.addActionListener(this);
        jButton16.setIcon(i16);
        jPanel2.add(jButton16);

        ImageIcon i17 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\YoungSheldon.png");
        jButton17 = new JButton();
        jButton17.setBounds(930, 190, 110, 150);
        jButton17.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton17.addActionListener(this);
        jButton17.setIcon(i17);
        jPanel2.add(jButton17);

        ImageIcon i18 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\The Great Kapil.png");
        jButton18 = new JButton();
        jButton18.setBounds(1060, 190, 110, 150);
        jButton18.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton18.addActionListener(this);
        jButton18.setIcon(i18);
        jPanel2.add(jButton18);

        ImageIcon i19 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\The Witcher.png");
        jButton19 = new JButton();
        jButton19.setBounds(1190, 190, 110, 150);
        jButton19.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton19.addActionListener(this);
        jButton19.setIcon(i19);
        jPanel2.add(jButton19);

        // Create a main panel to hold both jPanel and jPanel2
        mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setPreferredSize(new Dimension(1360, 1000)); // Adjust size as needed

        // Add jPanel and jPanel2 to mainPanel
        jPanel.setBounds(0, 0, 1360, 430); // Adjust size and position as needed
        mainPanel.add(jPanel);

        jPanel2.setBounds(0, 430, 1360, 600); // Adjust size and position as needed
        mainPanel.add(jPanel2);

        // Add mainPanel to JScrollPane
        jScrollPane = new JScrollPane(mainPanel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane.setBounds(40, 0, 1360, 760);

        jFrame.add(jPanel1);
        jFrame.add(jScrollPane);
        jFrame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==Account) {
            jFrame.dispose();
            new Accounts_KSection();
        }
        else if (e.getSource()==SHOWS) {
            jFrame.dispose();
            new Kids_Show();
        }
        else if (e.getSource()==CARTOONS) {
            jFrame.dispose();
            new Kids_Cartoons();
        }
        else if (e.getSource() == jButton) {
            jFrame.dispose();
            new Kid_Cartoon1();

        }
        else if (e.getSource() == jButton1) {
            jFrame.dispose();
            new Kid_Cartoon2();

        }
        else if (e.getSource() == jButton2) {
            jFrame.dispose();
            new Kid_Cartoon3();

        }
        else if (e.getSource() == jButton3) {
            jFrame.dispose();
            new Kid_Cartoon4();

        }
        else if (e.getSource() == jButton4) {
            jFrame.dispose();
            new Kid_Cartoon5();

        }
        else if (e.getSource() == jButton5) {
            jFrame.dispose();
            new Kid_Cartoon6();

        }
        else if (e.getSource() == jButton6) {
            jFrame.dispose();
            new Kid_Cartoon7();

        }
        else if (e.getSource() == jButton7) {
            jFrame.dispose();
            new Kid_Cartoon8();

        }
        else if (e.getSource() == jButton8) {
            jFrame.dispose();
            new Kid_Cartoon9();

        }
        else if (e.getSource() == jButton9) {
            jFrame.dispose();
            new Kid_Cartoon10();

        }
        else if (e.getSource()==jButton10) {
            jFrame.dispose();
            new Kid_Show11();

        }else if (e.getSource()==jButton11) {
            jFrame.dispose();
            new Kid_Show12();

        }else if (e.getSource()==jButton12) {
            jFrame.dispose();
            new Kid_Show13();

        }
        else if (e.getSource()==jButton13) {
            jFrame.dispose();
            new Kid_Show14();

        }else if (e.getSource()==jButton14) {
            jFrame.dispose();
            new Kid_Show15();

        }else if (e.getSource()==jButton15) {
            jFrame.dispose();
            new Kid_Show16();

        }else if (e.getSource()==jButton16) {
            jFrame.dispose();
            new Kid_Show17();

        }
        else if (e.getSource()==jButton17) {
            jFrame.dispose();
            new Kid_Show18();

        }
        else if (e.getSource()==jButton18) {
            jFrame.dispose();
            new Kid_Show19();

        }
        else if (e.getSource()==jButton19) {
            jFrame.dispose();
            new Kid_Show20();
        }else if (e.getSource()==Watch) {
            jFrame.dispose();
            new Kid_Cartoon7();
        }

    }
}
