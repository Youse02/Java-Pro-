package Java.Project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Select implements ActionListener {
    JFrame jFrame;
    JLabel jLabel,Name,Name2;
    JButton jButton,jButton1;
    JPanel jPanel;


     Select(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel = new JPanel();
        jPanel.setBounds(0, 0, 1400, 760);
        jPanel.setBackground(Color.black);
        jPanel.setLayout(null);

         ImageIcon i =new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Profile Main.png ");

         jButton = new JButton(i);
         jButton.setBounds(500, 300, 110, 100);
         jButton.addActionListener(this);
         jButton.setIcon(i);
         jPanel.add(jButton);
         
         Name = new JLabel("YOUSUF");
         Name.setForeground(Color.LIGHT_GRAY);
         Name.setBackground(Color.black);
         Name.setFont(new Font("Serif", Font.PLAIN, 12));
         Name.setBounds(530, 385, 100, 50); // Adjusted bounds to fit within the jPanel
         Name.setOpaque(true);
         jPanel.add(Name);

         ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Profile2.png ");
         jButton1 = new JButton(i2);
         jButton1.setBounds(700, 300, 110, 100);
         jButton1.addActionListener(this);
         jButton1.setIcon(i2);
         jPanel.add(jButton1);

         Name2 = new JLabel("KIDS");
         Name2.setForeground(Color.LIGHT_GRAY);
         Name2.setBackground(Color.black);
         Name2.setFont(new Font("Serif", Font.PLAIN, 12));
         Name2.setBounds(740, 385, 105, 50); // Adjusted bounds to fit within the jPanel
         Name2.setOpaque(true);
         jPanel.add(Name2);

         jLabel = new JLabel("CHOOSE WHO's WATCHING");
        jLabel.setForeground(Color.LIGHT_GRAY);
        jLabel.setBackground(Color.black);
        jLabel.setFont(new Font("Serif", Font.BOLD, 50));
        jLabel.setBounds(350, 200, 700, 50); // Adjusted bounds to fit within the jPanel
        jLabel.setOpaque(true);
        jPanel.add(jLabel);

          jFrame.add(jPanel);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==jButton){
            jFrame.dispose();
            new UI();
        } else if (e.getSource()==jButton1) {
            jFrame.dispose();
            new Kids_UI();
        }
    }
}
