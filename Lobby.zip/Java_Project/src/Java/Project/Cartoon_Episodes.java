package Java.Project;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.plaf.ColorUIResource;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

class Cartoon1 implements ActionListener {

     JFrame jFrame;
     JLabel jLabel;
     JButton Home, Account, jButton, jButton1, jButton2, jButton3, jButton4, jButton5, jButton6, jButton7, jButton8, jButton9;
     JButton jButton10, jButton11, jButton12;
     JPanel jPanel, jPanel1, jPanel2;
     JButton backButton;

     Cartoon1() {
         jFrame = new JFrame();
         jFrame.setSize(1400, 760);
         jFrame.setResizable(false);
         jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
         jFrame.setLayout(null);

         jPanel1 = new JPanel();
         jPanel1.setBounds(0, 0, 40, 760);
         jPanel1.setBackground(Color.BLACK);
         jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
         jPanel1.setLayout(null);

         ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
         Home = new JButton();
         Home.setBounds(0,1,40,40);
         Home.addActionListener(this);
         Home.setIcon(ih);

         jPanel1. add(Home);

         jPanel2 = new JPanel();
         jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
         jPanel2.setBackground(Color.BLACK);
         jPanel2.setLayout(null);

         ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton = new JButton();
         jButton.setBounds(20, 20, 110, 150);
         jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton.addActionListener(this);
         jButton.setIcon(i);
         jPanel2.add(jButton);

         ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton1 = new JButton();
         jButton1.setBounds(150, 20, 110, 150);
         jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton1.addActionListener(this);
         jButton1.setIcon(i1);
         jPanel2.add(jButton1);

         ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
         jButton2 = new JButton();
         jButton2.setBounds(280, 20, 110, 150);
         jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton2.addActionListener(this);
         jButton2.setIcon(i2);
         jPanel2.add(jButton2);

         ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton3 = new JButton();
         jButton3.setBounds(410, 20, 110, 150);
         jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton3.addActionListener(this);
         jButton3.setIcon(i3);
         jPanel2.add(jButton3);

         ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton4 = new JButton();
         jButton4.setBounds(540, 20, 110, 150);
         jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton4.addActionListener(this);
         jButton4.setIcon(i4);
         jPanel2.add(jButton4);

         ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton5 = new JButton();
         jButton5.setBounds(670, 20, 110, 150);
         jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton5.addActionListener(this);
         jButton5.setIcon(i5);
         jPanel2.add(jButton5);

         ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton6 = new JButton();
         jButton6.setBounds(800,20,110, 150);
         jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton6.addActionListener(this);
         jButton6.setIcon(i6);
         jPanel2.add(jButton6);

         ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton7 = new JButton();
         jButton7.setBounds(930, 20, 110, 150);
         jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton7.addActionListener(this);
         jButton7.setIcon(i7);
         jPanel2.add(jButton7);

         ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton8 = new JButton();
         jButton8.setBounds(1060, 20, 110, 150);
         jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton8.addActionListener(this);
         jButton8.setIcon(i8);
         jPanel2.add(jButton8);

         ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton9 = new JButton();
         jButton9.setBounds(1190, 20, 110, 150);
         jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton9.addActionListener(this);
         jButton9.setIcon(i9);
         jPanel2.add(jButton9);

         ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton10 = new JButton();
         jButton10.setBounds(20, 190, 110, 150);
         jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton10.addActionListener(this);
         jButton10.setIcon(i10);
         jPanel2.add(jButton10);

         ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton11 = new JButton();
         jButton11.setBounds(150, 190, 110, 150);
         jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton11.addActionListener(this);
         jButton11.setIcon(i11);
         jPanel2.add(jButton11);

         ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png ");
         jButton12 = new JButton();
         jButton12.setBounds(280, 190, 110, 150);
         jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton12.addActionListener(this);
         jButton12.setIcon(i12);
         jPanel2.add(jButton12);

         backButton = new JButton("Return");
         backButton.setBackground(Color.DARK_GRAY);
         backButton.setFont(new Font("Serif", Font.PLAIN, 12));
         backButton.setBounds(1200, 650, 100, 50);
         backButton.addActionListener(this);
         jPanel2.add(backButton);

         jFrame.add(jPanel1);
         jFrame.add(jPanel2);
         jFrame.setVisible(true);
     }


     @Override
     public void actionPerformed(ActionEvent e) {
         if (e.getSource() == Home) {
             jFrame.dispose();
             new UI();
         } else if (e.getSource() == backButton) {
             jFrame.dispose();
             new Cartoons();
         }
         else if (e.getSource() == jButton) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else if (e.getSource() == jButton1) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else if (e.getSource() == jButton2) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else if (e.getSource() == jButton3) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else  if (e.getSource() == jButton4) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else if (e.getSource() == jButton5) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else  if (e.getSource() == jButton6) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else if (e.getSource() == jButton7) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else if (e.getSource() == jButton8) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else if (e.getSource() == jButton9) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else if (e.getSource() == jButton10) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else if (e.getSource() == jButton11) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
         else if (e.getSource() == jButton12) {
             try {
                 ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                 pb.start();
             } catch (IOException a) {
                 a.printStackTrace();
             }
         }
     }

 }



class Cartoon2 implements ActionListener {


    JFrame jFrame;
    JButton Home,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel1, jPanel2;
    JButton backButton;

    Cartoon2(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760);
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon3 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;


    Cartoon3(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon4 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon4(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760);
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon5 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon5(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon6 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon6(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon7 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon7(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon8 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon8(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png  ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png  ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png  ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png  ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png  ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png  ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon9 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon9(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760);
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png  ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png  ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png  ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png  ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png  ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png  ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon10 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon10(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon11 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon11(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon12 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon12(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }

        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon13 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon13(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Flash.png");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon14 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon14(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon15 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon15(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png  ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png  ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png  ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png  ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png  ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png  ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png  ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png  ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon16 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon16(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon17 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon17(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon18 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon18(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

class Cartoon19 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon19(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }

}

class Cartoon20 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Cartoon20(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton("Return");
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setFont(new Font("Serif", Font.PLAIN, 12));
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Cartoons();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}


