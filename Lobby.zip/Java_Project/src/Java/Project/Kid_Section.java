package Java.Project;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.plaf.ColorUIResource;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


//SHOWS CLASS


class Kids_Show implements ActionListener {


    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    Kids_Show(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);


        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);


        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        ImageIcon i13 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Flash.png ");
        jButton13 = new JButton();
        jButton13.setBounds(410, 190, 110, 150);
        jButton13.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton13.addActionListener(this);
        jButton13.setIcon(i13);
        jPanel2.add(jButton13);

        ImageIcon i14 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Wednesday.png ");
        jButton14 = new JButton();
        jButton14.setBounds(540, 190, 110, 150);
        jButton14.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton14.addActionListener(this);
        jButton14.setIcon(i14);
        jPanel2.add(jButton14);

        ImageIcon i15 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\The Great Kapil.png ");
        jButton15 = new JButton();
        jButton15.setBounds(670, 190, 110, 150);
        jButton15.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton15.addActionListener(this);
        jButton15.setIcon(i15);
        jPanel2.add(jButton15);

        ImageIcon i16 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\SpyXFamily.png ");
        jButton16 = new JButton();
        jButton16.setBounds(800, 190, 110, 150);
        jButton16.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton16.addActionListener(this);
        jButton16.setIcon(i16);
        jPanel2.add(jButton16);

        ImageIcon i17 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton17 = new JButton();
        jButton17.setBounds(930, 190, 110, 150);
        jButton17.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton17.addActionListener(this);
        jButton17.setIcon(i17);
        jPanel2.add(jButton17);

        ImageIcon i18 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\MHA.png ");
        jButton18 = new JButton();
        jButton18.setBounds(1060, 190, 110, 150);
        jButton18.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton18.addActionListener(this);
        jButton18.setIcon(i18);
        jPanel2.add(jButton18);

        ImageIcon i19 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Hunter X.png ");
        jButton19 = new JButton();
        jButton19.setBounds(1190, 190, 110, 150);
        jButton19.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton19.addActionListener(this);
        jButton19.setIcon(i19);
        jPanel2.add(jButton19);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource()==Home) {
            jFrame.dispose();
            new Kids_UI();
        }
        else if (e.getSource()==jButton) {
            jFrame.dispose();
            new Kid_Show1();

        }
        else if (e.getSource()==jButton1) {
            jFrame.dispose();
            new Kid_Show2();
        }
        else if (e.getSource()==jButton2) {
            jFrame.dispose();
            new Kid_Show3();

        }
        else if (e.getSource()==jButton3) {
            jFrame.dispose();
            new Kid_Show4();

        }else if (e.getSource()==jButton4) {
            jFrame.dispose();
            new Kid_Show5();

        }else if (e.getSource()==jButton5) {
            jFrame.dispose();
            new Kid_Show6();

        }else if (e.getSource()==jButton6) {
            jFrame.dispose();
            new Kid_Show7();

        }else if (e.getSource()==jButton7) {
            jFrame.dispose();
            new Kid_Show8();

        }else if (e.getSource()==jButton8) {
            jFrame.dispose();
            new Kid_Show9();

        }else if (e.getSource()==jButton9) {
            jFrame.dispose();
            new Kid_Show10();

        }else if (e.getSource()==jButton10) {
            jFrame.dispose();
            new Kid_Show11();

        }else if (e.getSource()==jButton11) {
            jFrame.dispose();
            new Kid_Show12();

        }else if (e.getSource()==jButton12) {
            jFrame.dispose();
            new Kid_Show13();

        }
        else if (e.getSource()==jButton13) {
            jFrame.dispose();
            new Kid_Show14();

        }else if (e.getSource()==jButton14) {
            jFrame.dispose();
            new Kid_Show15();

        }else if (e.getSource()==jButton15) {
            jFrame.dispose();
            new Kid_Show16();

        }else if (e.getSource()==jButton16) {
            jFrame.dispose();
            new Kid_Show17();

        }
        else if (e.getSource()==jButton17) {
            jFrame.dispose();
            new Kid_Show18();

        }
        else if (e.getSource()==jButton18) {
            jFrame.dispose();
            new Kid_Show19();

        }
        else if (e.getSource()==jButton19) {
            jFrame.dispose();
            new Kid_Show20();

        }

    }
}


class Kid_Show1 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel  jPanel1, jPanel2;
    JButton backButton;

    Kid_Show1(){

        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}



class Kid_Show2 implements ActionListener {


    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show2(){

        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_Show();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show3 implements ActionListener {


    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show3(){

        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show4 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show4(){

        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show5 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show5(){

        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show6 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show6(){

        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show7 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show7(){

        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show8 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show8(){

        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        jButton11 = new JButton("Test2");
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.addActionListener(this);
        jPanel2.add(jButton11);

        jButton12 = new JButton("Test3");
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.addActionListener(this);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show9 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;
    Kid_Show9(){

        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show10 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show10(){
        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760);
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show11 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show11(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show12 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show12(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show13 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show13(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }

}

class Kid_Show14 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show14(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show15 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show15(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show16 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show16(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show17 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButto7n16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show17(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show18 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show18(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}

class Kid_Show19 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show19(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }

}

class Kid_Show20 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Show20(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Show();

        }
    }
}


// CARTOON CLASS

class Kids_Cartoons implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home, Account, jButton, jButton1, jButton2, jButton3, jButton4, jButton5, jButton6, jButton7, jButton8, jButton9;
    JButton jButton10, jButton11, jButton12, jButton13, jButton14, jButton15, jButton16, jButton17, jButton18, jButton19;
    JPanel jPanel, jPanel1, jPanel2;

    Kids_Cartoons() {
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);


        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);


        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        ImageIcon i13 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Flash.png ");
        jButton13 = new JButton();
        jButton13.setBounds(410, 190, 110, 150);
        jButton13.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton13.addActionListener(this);
        jButton13.setIcon(i13);
        jPanel2.add(jButton13);

        ImageIcon i14 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Wednesday.png ");
        jButton14 = new JButton();
        jButton14.setBounds(540, 190, 110, 150);
        jButton14.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton14.addActionListener(this);
        jButton14.setIcon(i14);
        jPanel2.add(jButton14);

        ImageIcon i15 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\The Great Kapil.png ");
        jButton15 = new JButton();
        jButton15.setBounds(670, 190, 110, 150);
        jButton15.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton15.addActionListener(this);
        jButton15.setIcon(i15);
        jPanel2.add(jButton15);

        ImageIcon i16 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\SpyXFamily.png ");
        jButton16 = new JButton();
        jButton16.setBounds(800, 190, 110, 150);
        jButton16.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton16.addActionListener(this);
        jButton16.setIcon(i16);
        jPanel2.add(jButton16);

        ImageIcon i17 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton17 = new JButton();
        jButton17.setBounds(930, 190, 110, 150);
        jButton17.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton17.addActionListener(this);
        jButton17.setIcon(i17);
        jPanel2.add(jButton17);

        ImageIcon i18 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\MHA.png ");
        jButton18 = new JButton();
        jButton18.setBounds(1060, 190, 110, 150);
        jButton18.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton18.addActionListener(this);
        jButton18.setIcon(i18);
        jPanel2.add(jButton18);

        ImageIcon i19 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Hunter X.png ");
        jButton19 = new JButton();
        jButton19.setBounds(1190, 190, 110, 150);
        jButton19.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton19.addActionListener(this);
        jButton19.setIcon(i19);
        jPanel2.add(jButton19);

        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Home) {
            jFrame.dispose();
            new Kids_UI();
        } else if (e.getSource() == jButton) {
            jFrame.dispose();
            new Kid_Cartoon1();

        }
        else if (e.getSource() == jButton1) {
            jFrame.dispose();
            new Kid_Cartoon2();

        }
        else if (e.getSource() == jButton2) {
            jFrame.dispose();
            new Kid_Cartoon3();

        }
        else if (e.getSource() == jButton3) {
            jFrame.dispose();
            new Kid_Cartoon4();

        }
        else if (e.getSource() == jButton4) {
            jFrame.dispose();
            new Kid_Cartoon5();

        }
        else if (e.getSource() == jButton5) {
            jFrame.dispose();
            new Kid_Cartoon6();

        }
        else if (e.getSource() == jButton6) {
            jFrame.dispose();
            new Kid_Cartoon7();

        }
        else if (e.getSource() == jButton7) {
            jFrame.dispose();
            new Kid_Cartoon8();

        }
        else if (e.getSource() == jButton8) {
            jFrame.dispose();
            new Kid_Cartoon9();

        }
        else if (e.getSource() == jButton9) {
            jFrame.dispose();
            new Kid_Cartoon20();

        }
        else if (e.getSource() == jButton10) {
            jFrame.dispose();
            new Kid_Cartoon20();

        }
        else if (e.getSource() == jButton11) {
            jFrame.dispose();
            new Kid_Cartoon20();

        }
        else if (e.getSource() == jButton12) {
            jFrame.dispose();
            new Kid_Cartoon20();

        }
        else if (e.getSource() == jButton13) {
            jFrame.dispose();
            new Kid_Cartoon20();

        }
        else if (e.getSource() == jButton14) {
            jFrame.dispose();
            new Kid_Cartoon20();

        }
        else if (e.getSource() == jButton15) {
            jFrame.dispose();
            new Kid_Cartoon20();

        }
        else if (e.getSource() == jButton16) {
            jFrame.dispose();
            new Kid_Cartoon20();

        }
        else if (e.getSource() == jButton17) {
            jFrame.dispose();
            new Kid_Cartoon20();

        }
        else if (e.getSource() == jButton18) {
            jFrame.dispose();
            new Kid_Cartoon20();

        }
        else if (e.getSource() == jButton19) {
            jFrame.dispose();
            new Kid_Cartoon20();

        }
    }
}


class Kid_Cartoon1 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon1(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
        }
    }




class Kid_Cartoon2 implements ActionListener {


    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon2(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon3 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;


    Kid_Cartoon3(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon4 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

   Kid_Cartoon4(){
       jFrame = new JFrame();
       jFrame.setSize(1400, 760);
       jFrame.setResizable(false);
       jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
       jFrame.setLayout(null);

       jPanel1 = new JPanel();
       jPanel1.setBounds(0, 0, 40, 760);
       jPanel1.setBackground(Color.BLACK);
       jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
       jPanel1.setLayout(null);

       ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
       Home = new JButton();
       Home.setBounds(0,1,40,40);
       Home.addActionListener(this);
       Home.setIcon(ih);

       jPanel1. add(Home);

       jPanel2 = new JPanel();
       jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
       jPanel2.setBackground(Color.BLACK);
       jPanel2.setLayout(null);

       ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
       jButton = new JButton();
       jButton.setBounds(20, 20, 110, 150);
       jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton.addActionListener(this);
       jButton.setIcon(i);
       jPanel2.add(jButton);

       ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
       jButton1 = new JButton();
       jButton1.setBounds(150, 20, 110, 150);
       jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton1.addActionListener(this);
       jButton1.setIcon(i1);
       jPanel2.add(jButton1);

       ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
       jButton2 = new JButton();
       jButton2.setBounds(280, 20, 110, 150);
       jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton2.addActionListener(this);
       jButton2.setIcon(i2);
       jPanel2.add(jButton2);

       ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
       jButton3 = new JButton();
       jButton3.setBounds(410, 20, 110, 150);
       jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton3.addActionListener(this);
       jButton3.setIcon(i3);
       jPanel2.add(jButton3);

       ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
       jButton4 = new JButton();
       jButton4.setBounds(540, 20, 110, 150);
       jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton4.addActionListener(this);
       jButton4.setIcon(i4);
       jPanel2.add(jButton4);

       ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
       jButton5 = new JButton();
       jButton5.setBounds(670, 20, 110, 150);
       jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton5.addActionListener(this);
       jButton5.setIcon(i5);
       jPanel2.add(jButton5);

       ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
       jButton6 = new JButton();
       jButton6.setBounds(800,20,110, 150);
       jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton6.addActionListener(this);
       jButton6.setIcon(i6);
       jPanel2.add(jButton6);

       ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
       jButton7 = new JButton();
       jButton7.setBounds(930, 20, 110, 150);
       jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton7.addActionListener(this);
       jButton7.setIcon(i7);
       jPanel2.add(jButton7);

       ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
       jButton8 = new JButton();
       jButton8.setBounds(1060, 20, 110, 150);
       jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton8.addActionListener(this);
       jButton8.setIcon(i8);
       jPanel2.add(jButton8);

       ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
       jButton9 = new JButton();
       jButton9.setBounds(1190, 20, 110, 150);
       jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton9.addActionListener(this);
       jButton9.setIcon(i9);
       jPanel2.add(jButton9);

       ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
       jButton10 = new JButton();
       jButton10.setBounds(20, 190, 110, 150);
       jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton10.addActionListener(this);
       jButton10.setIcon(i10);
       jPanel2.add(jButton10);

       ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
       jButton11 = new JButton();
       jButton11.setBounds(150, 190, 110, 150);
       jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton11.addActionListener(this);
       jButton11.setIcon(i11);
       jPanel2.add(jButton11);

       ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
       jButton12 = new JButton();
       jButton12.setBounds(280, 190, 110, 150);
       jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
       jButton12.addActionListener(this);
       jButton12.setIcon(i12);
       jPanel2.add(jButton12);

       backButton = new JButton();
       backButton.setBounds(1200,650,100,50);
       backButton.addActionListener(this);
       jPanel2.add(backButton);


       jFrame.add(jPanel1);
       jFrame.add(jPanel2);
       jFrame.setVisible(true);
   }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon5 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon5(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon6 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon6(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon7 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon7(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon8 implements ActionListener {

    JFrame jFrame;
    JButton Home,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon8() {
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0, 1, 40, 40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1.add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800, 20, 110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon9 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon9(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon10 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon10(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon11 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon11(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon12 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon12(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon13 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon13(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon14 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon14(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon15 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon15(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon16 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon16(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon17 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon17(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon18 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon18(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}

class Kid_Cartoon19 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon19(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }

}

class Kid_Cartoon20 implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12;
    JPanel jPanel,jPanel1, jPanel2;
    JButton backButton;

    Kid_Cartoon20(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);

        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png ");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        backButton = new JButton();
        backButton.setBounds(1200,650,100,50);
        backButton.addActionListener(this);
        jPanel2.add(backButton);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new Kids_UI();
        }
        else if (e.getSource()==backButton) {
            jFrame. dispose();
            new Kids_Cartoons();

        }
    }
}







