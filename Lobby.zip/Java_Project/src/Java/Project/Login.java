package Java.Project;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.plaf.ColorUIResource;
import java.awt.*;
import java.awt.event.*;

public class Login implements ActionListener{
    JFrame frame;

    JTextField usernameField;
    JPasswordField passwordField;
    JButton loginPls;
    ImageIcon title;
    JPanel panel;
     Login() {

         frame=new JFrame();

        frame.setTitle("Login Page");
        frame.setSize(1400, 760);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
        title=new ImageIcon("title.png");
        frame.setIconImage(title.getImage());


        panel = new JPanel();
        panel.setBounds(650,150,600,450);
        panel.setBackground(new Color(59,59,59));
        panel.setLayout(null);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.LIGHT_GRAY);
        usernameLabel.setFont(new Font("Default", Font.BOLD, 12));
        usernameLabel.setBounds(100,135,200,25);
        usernameField = new JTextField();
        usernameField.setBounds(100,170,350,35);

        JLabel passwordLabel = new JLabel("Password:");
         passwordLabel.setForeground(Color.LIGHT_GRAY);
         passwordLabel.setFont(new Font("Default", Font.BOLD, 12));
         passwordLabel.setBounds(100,220,90,25);
        passwordField = new JPasswordField();
        passwordField.setBounds(100,250,350,35);


        loginPls = new JButton("Login");
        loginPls.setForeground(Color.WHITE);
        loginPls.setFont(new Font("Default", Font.BOLD, 12));
        loginPls.setBackground(new Color(170, 37, 36));
        loginPls.setFocusable(false);
        loginPls.setBorder(new LineBorder(new Color(170, 37, 36)));
        loginPls.setBounds(100,340,350,40);
        loginPls.addActionListener(this);

        JLabel welcome = new JLabel("WELCOME..!");
        welcome.setForeground(Color.lightGray);
        welcome.setBounds(205,30,150,60);
        welcome.setFont(new Font("Default", Font.BOLD, 20));
        panel.add(welcome);

         JLabel welcome2 = new JLabel("WE'RE SO EXCITED TO SEE YOU AGAIN");
         welcome2.setForeground(Color.lightGray);
         welcome2.setBounds(130,60,350,60);
         welcome2.setFont(new Font("Default", Font.BOLD, 16));
         panel.add(welcome2);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Red 2.png ");
        JLabel j = new JLabel();
        j.setBounds(0,0,1400,760);
        j.setIcon(i);



        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginPls);

        frame.add(panel);
         frame.add(j);
        frame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (username.equals("admin") && password.equals("admin")) {
            new Select();
            frame.dispose();
            //frame.setVisible(false);
        }else {
            JOptionPane.showMessageDialog(frame, "Invalid username or password!");
        }

    }
    public static void main(String[] args) {
        new Login();
    }
}
