package Java.Project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pic implements ActionListener {
    JFrame jFrame;

    Pic() {
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        jFrame.setLayout(null);


        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\IdeaProjects\\Java_Project\\src\\Java\\Project\\wallpaperflare.com_wallpaper (3).jpg");

        JLabel j = new JLabel();
        j.setBounds(0, 0, 1400, 760);
        j.setIcon(i);
        j.setOpaque(true);

        jFrame.add(j);
        jFrame.setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}