package Java.Project;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.plaf.ColorUIResource;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

class Movies implements ActionListener {
    JFrame jFrame;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;
    Movies(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);


        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);


        jPanel1. add(Home);


        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Animal.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\BossBaby.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Bahubali 2.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\BatmanBegins.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Brothers.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Dil Wele.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\HappyNewYear.png");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Jawan.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\KabhiKhushiKabhiGhum.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\LEO.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\MainHoonNA.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Malang.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\om Shanti om.png ");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        ImageIcon i13 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\PK.png ");
        jButton13 = new JButton();
        jButton13.setBounds(410, 190, 110, 150);
        jButton13.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton13.addActionListener(this);
        jButton13.setIcon(i13);
        jPanel2.add(jButton13);

        ImageIcon i14 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Raees.png");
        jButton14 = new JButton();
        jButton14.setBounds(540, 190, 110, 150);
        jButton14.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton14.addActionListener(this);
        jButton14.setIcon(i14);
        jPanel2.add(jButton14);

        ImageIcon i15 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Shehzada.png");
        jButton15 = new JButton();
        jButton15.setBounds(670, 190, 110, 150);
        jButton15.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton15.addActionListener(this);
        jButton15.setIcon(i15);
        jPanel2.add(jButton15);

        ImageIcon i16 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\SpiderMan Homecoming.png ");
        jButton16 = new JButton();
        jButton16.setBounds(800, 190, 110, 150);
        jButton16.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton16.addActionListener(this);
        jButton16.setIcon(i16);
        jPanel2.add(jButton16);

        ImageIcon i17 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\SpidermanAcrossTheSpiderVerse.png ");
        jButton17 = new JButton();
        jButton17.setBounds(930, 190, 110, 150);
        jButton17.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton17.addActionListener(this);
        jButton17.setIcon(i17);
        jPanel2.add(jButton17);

        ImageIcon i18 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\Stuart Little 2.png");
        jButton18 = new JButton();
        jButton18.setBounds(1060, 190, 110, 150);
        jButton18.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton18.addActionListener(this);
        jButton18.setIcon(i18);
        jPanel2.add(jButton18);

        ImageIcon i19 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Movies\\The Amezing Spiderman.pmg.png ");
        jButton19 = new JButton();
        jButton19.setBounds(1190, 190, 110, 150);
        jButton19.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton19.addActionListener(this);
        jButton19.setIcon(i19);
        jPanel2.add(jButton19);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        //  jFrame.add(jPanel);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home){
            jFrame .dispose();
            new UI();
        }
        else if (e.getSource() == jButton) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton1) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton2) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton3) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton4) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton5) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else  if (e.getSource() == jButton6) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton7) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton8) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton9) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton10) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton11) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton12) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton13) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton14) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton15) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton16) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton17) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton18) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
        else if (e.getSource() == jButton19) {
            try {
                ProcessBuilder pb = new ProcessBuilder("C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe ", "C:\\Users\\yousa\\Downloads\\Video\\Judai.mp4 ");
                pb.start();
            } catch (IOException a) {
                a.printStackTrace();
            }
        }
    }
}

// ANIME CLASS



class Animes implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;;
    Animes(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);


        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);



        jPanel1. add(Home);



        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Baki Hanma.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Assissin Classroom.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\BlackClover.png ");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\OnePiece.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\BlueLock.png ");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Boruto.png ");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\ChainSawMan.png ");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\ClassRoomOfThe Elite.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\CyberPunk.png");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Dr Stone.png ");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\My Demon.png");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        ImageIcon i13 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\JujutsuKaisan.png");
        jButton13 = new JButton();
        jButton13.setBounds(410, 190, 110, 150);
        jButton13.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton13.addActionListener(this);
        jButton13.setIcon(i13);
        jPanel2.add(jButton13);

        ImageIcon i14 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Naruto.png");
        jButton14 = new JButton();
        jButton14.setBounds(540, 190, 110, 150);
        jButton14.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton14.addActionListener(this);
        jButton14.setIcon(i14);
        jPanel2.add(jButton14);

        ImageIcon i15 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Naruto 2.png");
        jButton15 = new JButton();
        jButton15.setBounds(670, 190, 110, 150);
        jButton15.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton15.addActionListener(this);
        jButton15.setIcon(i15);
        jPanel2.add(jButton15);

        ImageIcon i16 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Oshi No Ko.png ");
        jButton16 = new JButton();
        jButton16.setBounds(800, 190, 110, 150);
        jButton16.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton16.addActionListener(this);
        jButton16.setIcon(i16);
        jPanel2.add(jButton16);

        ImageIcon i17 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Demon Slayer.png ");
        jButton17 = new JButton();
        jButton17.setBounds(930, 190, 110, 150);
        jButton17.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton17.addActionListener(this);
        jButton17.setIcon(i17);
        jPanel2.add(jButton17);

        ImageIcon i18 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\MHA.png ");
        jButton18 = new JButton();
        jButton18.setBounds(1060, 190, 110, 150);
        jButton18.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton18.addActionListener(this);
        jButton18.setIcon(i18);
        jPanel2.add(jButton18);

        ImageIcon i19 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Animes\\Hunter X.png ");
        jButton19 = new JButton();
        jButton19.setBounds(1190, 190, 110, 150);
        jButton19.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton19.addActionListener(this);
        jButton19.setIcon(i19);
        jPanel2.add(jButton19);



        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Home) {
            jFrame.dispose();
            new UI();
        }
        else if (e.getSource()==jButton) {
            jFrame.dispose();
            new Anime1();

        }
        else if (e.getSource()==jButton1) {
            jFrame.dispose();
            new Anime2();
        }
        else if (e.getSource()==jButton2) {
            jFrame.dispose();
            new Anime3();

        }
        else if (e.getSource()==jButton3) {
            jFrame.dispose();
            new Anime4();

        }else if (e.getSource()==jButton4) {
            jFrame.dispose();
            new Anime5();

        }else if (e.getSource()==jButton5) {
            jFrame.dispose();
            new Anime6();

        }else if (e.getSource()==jButton6) {
            jFrame.dispose();
            new Anime7();

        }else if (e.getSource()==jButton7) {
            jFrame.dispose();
            new Anime8();

        }else if (e.getSource()==jButton8) {
            jFrame.dispose();
            new Anime9();

        }else if (e.getSource()==jButton9) {
            jFrame.dispose();
            new Anime10();

        }else if (e.getSource()==jButton10) {
            jFrame.dispose();
            new Anime11();

        }else if (e.getSource()==jButton11) {
            jFrame.dispose();
            new Anime12();

        }else if (e.getSource()==jButton12) {
            jFrame.dispose();
            new Anime13();

        }
        else if (e.getSource()==jButton13) {
            jFrame.dispose();
            new Anime14();

        }else if (e.getSource()==jButton14) {
            jFrame.dispose();
            new Anime15();

        }else if (e.getSource()==jButton15) {
            jFrame.dispose();
            new Anime16();

        }else if (e.getSource()==jButton16) {
            jFrame.dispose();
            new Anime17();

        }
        else if (e.getSource()==jButton17) {
            jFrame.dispose();
            new Anime18();

        }
        else if (e.getSource()==jButton18) {
            jFrame.dispose();
            new Anime19();

        }
        else if (e.getSource()==jButton19) {
            jFrame.dispose();
            new Anime20();

        }

        }
    }


//SHOWS CLASS



class Shows implements ActionListener {

    JFrame jFrame;
    JLabel jLabel;
    JButton Home,Account,jButton,jButton1,jButton2,jButton3,jButton4,jButton5,jButton6,jButton7,jButton8,jButton9;
    JButton jButton10,jButton11,jButton12,jButton13,jButton14,jButton15,jButton16,jButton17,jButton18,jButton19;
    JPanel jPanel,jPanel1, jPanel2;;
    Shows(){
        jFrame = new JFrame();
        jFrame.setSize(1400, 760);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame.setLayout(null);

        jPanel1 = new JPanel();
        jPanel1.setBounds(0, 0, 40, 760);
        jPanel1.setBackground(Color.BLACK);
        jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
        jPanel1.setLayout(null);

        ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
        Home = new JButton();
        Home.setBounds(0,1,40,40);
        Home.addActionListener(this);
        Home.setIcon(ih);

        jPanel1. add(Home);


        jPanel2 = new JPanel();
        jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
        jPanel2.setBackground(Color.BLACK);
        jPanel2.setLayout(null);

        ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Arcane.png ");
        jButton = new JButton();
        jButton.setBounds(20, 20, 110, 150);
        jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton.addActionListener(this);
        jButton.setIcon(i);
        jPanel2.add(jButton);

        ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Beauty Inside.png ");
        jButton1 = new JButton();
        jButton1.setBounds(150, 20, 110, 150);
        jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton1.addActionListener(this);
        jButton1.setIcon(i1);
        jPanel2.add(jButton1);

        ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Vincenzo.png");
        jButton2 = new JButton();
        jButton2.setBounds(280, 20, 110, 150);
        jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton2.addActionListener(this);
        jButton2.setIcon(i2);
        jPanel2.add(jButton2);

        ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Choona.png");
        jButton3 = new JButton();
        jButton3.setBounds(410, 20, 110, 150);
        jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton3.addActionListener(this);
        jButton3.setIcon(i3);
        jPanel2.add(jButton3);

        ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Cursed.png");
        jButton4 = new JButton();
        jButton4.setBounds(540, 20, 110, 150);
        jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton4.addActionListener(this);
        jButton4.setIcon(i4);
        jPanel2.add(jButton4);

        ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Wednesday.png");
        jButton5 = new JButton();
        jButton5.setBounds(670, 20, 110, 150);
        jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton5.addActionListener(this);
        jButton5.setIcon(i5);
        jPanel2.add(jButton5);

        ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Falling into your smile.png");
        jButton6 = new JButton();
        jButton6.setBounds(800,20,110, 150);
        jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton6.addActionListener(this);
        jButton6.setIcon(i6);
        jPanel2.add(jButton6);

        ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Flash.png");
        jButton7 = new JButton();
        jButton7.setBounds(930, 20, 110, 150);
        jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton7.addActionListener(this);
        jButton7.setIcon(i7);
        jPanel2.add(jButton7);

        ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\I'm not a Robot.png ");
        jButton8 = new JButton();
        jButton8.setBounds(1060, 20, 110, 150);
        jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton8.addActionListener(this);
        jButton8.setIcon(i8);
        jPanel2.add(jButton8);

        ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Kota Factory.png ");
        jButton9 = new JButton();
        jButton9.setBounds(1190, 20, 110, 150);
        jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton9.addActionListener(this);
        jButton9.setIcon(i9);
        jPanel2.add(jButton9);

        ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Lucifer.png ");
        jButton10 = new JButton();
        jButton10.setBounds(20, 190, 110, 150);
        jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton10.addActionListener(this);
        jButton10.setIcon(i10);
        jPanel2.add(jButton10);

        ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Man VS Bee.png");
        jButton11 = new JButton();
        jButton11.setBounds(150, 190, 110, 150);
        jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton11.addActionListener(this);
        jButton11.setIcon(i11);
        jPanel2.add(jButton11);

        ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Money Heist.png");
        jButton12 = new JButton();
        jButton12.setBounds(280, 190, 110, 150);
        jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton12.addActionListener(this);
        jButton12.setIcon(i12);
        jPanel2.add(jButton12);

        ImageIcon i13 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\OnePiece Show.png");
        jButton13 = new JButton();
        jButton13.setBounds(410, 190, 110, 150);
        jButton13.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton13.addActionListener(this);
        jButton13.setIcon(i13);
        jPanel2.add(jButton13);

        ImageIcon i14 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\PeakyBlinder.png ");
        jButton14 = new JButton();
        jButton14.setBounds(540, 190, 110, 150);
        jButton14.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton14.addActionListener(this);
        jButton14.setIcon(i14);
        jPanel2.add(jButton14);

        ImageIcon i15 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\School 2017.png");
        jButton15 = new JButton();
        jButton15.setBounds(670, 190, 110, 150);
        jButton15.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton15.addActionListener(this);
        jButton15.setIcon(i15);
        jPanel2.add(jButton15);

        ImageIcon i16 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\Squid Game.png");
        jButton16 = new JButton();
        jButton16.setBounds(800, 190, 110, 150);
        jButton16.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton16.addActionListener(this);
        jButton16.setIcon(i16);
        jPanel2.add(jButton16);

        ImageIcon i17 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\YoungSheldon.png");
        jButton17 = new JButton();
        jButton17.setBounds(930, 190, 110, 150);
        jButton17.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton17.addActionListener(this);
        jButton17.setIcon(i17);
        jPanel2.add(jButton17);

        ImageIcon i18 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\The Great Kapil.png");
        jButton18 = new JButton();
        jButton18.setBounds(1060, 190, 110, 150);
        jButton18.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton18.addActionListener(this);
        jButton18.setIcon(i18);
        jPanel2.add(jButton18);

        ImageIcon i19 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Shows\\The Witcher.png");
        jButton19 = new JButton();
        jButton19.setBounds(1190, 190, 110, 150);
        jButton19.setBorder(new LineBorder(ColorUIResource.BLACK));
        jButton19.addActionListener(this);
        jButton19.setIcon(i19);
        jPanel2.add(jButton19);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);
        jFrame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource()==Home) {
            jFrame.dispose();
            new UI();
        }
         else if (e.getSource()==jButton) {
                jFrame.dispose();
                new Show1();

            }
         else if (e.getSource()==jButton1) {
            jFrame.dispose();
            new Show2();
        }
        else if (e.getSource()==jButton2) {
            jFrame.dispose();
            new Show3();

        }
        else if (e.getSource()==jButton3) {
            jFrame.dispose();
            new Show4();

        }else if (e.getSource()==jButton4) {
            jFrame.dispose();
            new Show5();

        }else if (e.getSource()==jButton5) {
            jFrame.dispose();
            new Show6();

        }else if (e.getSource()==jButton6) {
            jFrame.dispose();
            new Show7();

        }else if (e.getSource()==jButton7) {
            jFrame.dispose();
            new Show8();

        }else if (e.getSource()==jButton8) {
            jFrame.dispose();
            new Show9();

        }else if (e.getSource()==jButton9) {
            jFrame.dispose();
            new Show10();

        }else if (e.getSource()==jButton10) {
            jFrame.dispose();
            new Show11();

        }else if (e.getSource()==jButton11) {
            jFrame.dispose();
            new Show12();

        }else if (e.getSource()==jButton12) {
            jFrame.dispose();
            new Show13();

        }
        else if (e.getSource()==jButton13) {
            jFrame.dispose();
            new Show14();

        }else if (e.getSource()==jButton14) {
            jFrame.dispose();
            new Show15();

        }else if (e.getSource()==jButton15) {
            jFrame.dispose();
            new Show16();

        }else if (e.getSource()==jButton16) {
            jFrame.dispose();
            new Show17();

        }
        else if (e.getSource()==jButton17) {
            jFrame.dispose();
            new Show18();

        }
        else if (e.getSource()==jButton18) {
            jFrame.dispose();
            new Show19();

        }
        else if (e.getSource()==jButton19) {
            jFrame.dispose();
            new Show20();

        }

    }
}

// CARTOON CLASS

 class Cartoons implements ActionListener {

     JFrame jFrame;
     JLabel jLabel;
     JButton Home, Account, jButton, jButton1, jButton2, jButton3, jButton4, jButton5, jButton6, jButton7, jButton8, jButton9;
     JButton jButton10, jButton11, jButton12, jButton13, jButton14, jButton15, jButton16, jButton17, jButton18, jButton19;
     JPanel jPanel, jPanel1, jPanel2;

     Cartoons() {
         jFrame = new JFrame();
         jFrame.setSize(1400, 760);
         jFrame.setResizable(false);
         jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
         jFrame.setLayout(null);


         jPanel1 = new JPanel();
         jPanel1.setBounds(0, 0, 40, 760);
         jPanel1.setBackground(Color.BLACK);
         jPanel1.setBorder(new LineBorder(Color.LIGHT_GRAY));
         jPanel1.setLayout(null);

         ImageIcon ih = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\home pro.png");
         Home = new JButton();
         Home.setBounds(0,1,40,40);
         Home.addActionListener(this);
         Home.setIcon(ih);

         jPanel1. add(Home);


         jPanel2 = new JPanel();
         jPanel2.setBounds(30, 0, 1360, 760); // Adjusted bounds to fit within the jFrame and avoid overlap with jPanel1
         jPanel2.setBackground(Color.BLACK);
         jPanel2.setLayout(null);

         ImageIcon i = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Adventure Time.png");
         jButton = new JButton();
         jButton.setBounds(20, 20, 110, 150);
         jButton.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton.addActionListener(this);
         jButton.setIcon(i);
         jPanel2.add(jButton);

         ImageIcon i1 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Ben 10.png");
         jButton1 = new JButton();
         jButton1.setBounds(150, 20, 110, 150);
         jButton1.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton1.addActionListener(this);
         jButton1.setIcon(i1);
         jPanel2.add(jButton1);

         ImageIcon i2 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\BeyBlade.png");
         jButton2 = new JButton();
         jButton2.setBounds(280, 20, 110, 150);
         jButton2.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton2.addActionListener(this);
         jButton2.setIcon(i2);
         jPanel2.add(jButton2);

         ImageIcon i3 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Grizzy.png");
         jButton3 = new JButton();
         jButton3.setBounds(410, 20, 110, 150);
         jButton3.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton3.addActionListener(this);
         jButton3.setIcon(i3);
         jPanel2.add(jButton3);

         ImageIcon i4 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\GumBall.png");
         jButton4 = new JButton();
         jButton4.setBounds(540, 20, 110, 150);
         jButton4.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton4.addActionListener(this);
         jButton4.setIcon(i4);
         jPanel2.add(jButton4);

         ImageIcon i5 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\IronMan.png ");
         jButton5 = new JButton();
         jButton5.setBounds(670, 20, 110, 150);
         jButton5.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton5.addActionListener(this);
         jButton5.setIcon(i5);
         jPanel2.add(jButton5);

         ImageIcon i6 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\JohnnyTest.png");
         jButton6 = new JButton();
         jButton6.setBounds(800,20,110, 150);
         jButton6.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton6.addActionListener(this);
         jButton6.setIcon(i6);
         jPanel2.add(jButton6);

         ImageIcon i7 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Tom&Jerry.png ");
         jButton7 = new JButton();
         jButton7.setBounds(930, 20, 110, 150);
         jButton7.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton7.addActionListener(this);
         jButton7.setIcon(i7);
         jPanel2.add(jButton7);

         ImageIcon i8 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Oggy.png ");
         jButton8 = new JButton();
         jButton8.setBounds(1060, 20, 110, 150);
         jButton8.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton8.addActionListener(this);
         jButton8.setIcon(i8);
         jPanel2.add(jButton8);

         ImageIcon i9 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Justic League.png");
         jButton9 = new JButton();
         jButton9.setBounds(1190, 20, 110, 150);
         jButton9.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton9.addActionListener(this);
         jButton9.setIcon(i9);
         jPanel2.add(jButton9);

         ImageIcon i10 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\The Batman.png");
         jButton10 = new JButton();
         jButton10.setBounds(20, 190, 110, 150);
         jButton10.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton10.addActionListener(this);
         jButton10.setIcon(i10);
         jPanel2.add(jButton10);

         ImageIcon i11 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Little Poney.png");
         jButton11 = new JButton();
         jButton11.setBounds(150, 190, 110, 150);
         jButton11.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton11.addActionListener(this);
         jButton11.setIcon(i11);
         jPanel2.add(jButton11);

         ImageIcon i12 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\LooneyToons.png");
         jButton12 = new JButton();
         jButton12.setBounds(280, 190, 110, 150);
         jButton12.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton12.addActionListener(this);
         jButton12.setIcon(i12);
         jPanel2.add(jButton12);

         ImageIcon i13 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TeenTitans.png ");
         jButton13 = new JButton();
         jButton13.setBounds(410, 190, 110, 150);
         jButton13.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton13.addActionListener(this);
         jButton13.setIcon(i13);
         jPanel2.add(jButton13);

         ImageIcon i14 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Masha and the Bears.png ");
         jButton14 = new JButton();
         jButton14.setBounds(540, 190, 110, 150);
         jButton14.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton14.addActionListener(this);
         jButton14.setIcon(i14);
         jPanel2.add(jButton14);

         ImageIcon i15 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\TalkingTom.png ");
         jButton15 = new JButton();
         jButton15.setBounds(670, 190, 110, 150);
         jButton15.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton15.addActionListener(this);
         jButton15.setIcon(i15);
         jPanel2.add(jButton15);

         ImageIcon i16 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PJMasks.png ");
         jButton16 = new JButton();
         jButton16.setBounds(800, 190, 110, 150);
         jButton16.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton16.addActionListener(this);
         jButton16.setIcon(i16);
         jPanel2.add(jButton16);

         ImageIcon i17 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\PowerPuffGirls.png ");
         jButton17 = new JButton();
         jButton17.setBounds(930, 190, 110, 150);
         jButton17.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton17.addActionListener(this);
         jButton17.setIcon(i17);
         jPanel2.add(jButton17);

         ImageIcon i18 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\ScobyDo.png");
         jButton18 = new JButton();
         jButton18.setBounds(1060, 190, 110, 150);
         jButton18.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton18.addActionListener(this);
         jButton18.setIcon(i18);
         jPanel2.add(jButton18);

         ImageIcon i19 = new ImageIcon("C:\\Users\\yousa\\Desktop\\Logos\\Cartoons\\Shaun the Sheep.png ");
         jButton19 = new JButton();
         jButton19.setBounds(1190, 190, 110, 150);
         jButton19.setBorder(new LineBorder(ColorUIResource.BLACK));
         jButton19.addActionListener(this);
         jButton19.setIcon(i19);
         jPanel2.add(jButton19);

         jFrame.add(jPanel1);
         jFrame.add(jPanel2);
         jFrame.setVisible(true);
     }


     @Override
     public void actionPerformed(ActionEvent e) {
         if (e.getSource() == Home) {
             jFrame.dispose();
             new UI();
         } else if (e.getSource() == jButton) {
             jFrame.dispose();
             new Cartoon1();

         }
         else if (e.getSource() == jButton1) {
             jFrame.dispose();
             new Cartoon2();

         }
         else if (e.getSource() == jButton2) {
             jFrame.dispose();
             new Cartoon3();

         }
         else if (e.getSource() == jButton3) {
             jFrame.dispose();
             new Cartoon4();

         }
         else if (e.getSource() == jButton4) {
             jFrame.dispose();
             new Cartoon5();

         }
         else if (e.getSource() == jButton5) {
             jFrame.dispose();
             new Cartoon6();

         }
         else if (e.getSource() == jButton6) {
             jFrame.dispose();
             new Cartoon7();

         }
         else if (e.getSource() == jButton7) {
             jFrame.dispose();
             new Cartoon8();

         }
         else if (e.getSource() == jButton8) {
             jFrame.dispose();
             new Cartoon9();

         }
         else if (e.getSource() == jButton9) {
             jFrame.dispose();
             new Cartoon10();

         }
         else if (e.getSource() == jButton10) {
             jFrame.dispose();
             new Cartoon11();

         }
         else if (e.getSource() == jButton11) {
             jFrame.dispose();
             new Cartoon12();

         }
         else if (e.getSource() == jButton12) {
             jFrame.dispose();
             new Cartoon13();

         }
         else if (e.getSource() == jButton13) {
             jFrame.dispose();
             new Cartoon14();

         }
         else if (e.getSource() == jButton14) {
             jFrame.dispose();
             new Cartoon15();

         }
         else if (e.getSource() == jButton15) {
             jFrame.dispose();
             new Cartoon16();

         }
         else if (e.getSource() == jButton16) {
             jFrame.dispose();
             new Cartoon17();

         }
         else if (e.getSource() == jButton17) {
             jFrame.dispose();
             new Cartoon18();

         }
         else if (e.getSource() == jButton18) {
             jFrame.dispose();
             new Cartoon19();

         }
         else if (e.getSource() == jButton19) {
             jFrame.dispose();
             new Cartoon20();

         }
     }
 }



